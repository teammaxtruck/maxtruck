from django.contrib import admin
from backend.models import User,Images
from backend.models  import Products
from backend.models import Categories
from backend.models import Brands
from backend.models import Services,Userservices,Workers
from .models import *
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

class UserModelAdmin(BaseUserAdmin):
 
    # The fields to be used in displaying the User model.
    # These override the definitions on the base UserModelAdmin
    # that reference specific fields on auth.User.
    #   
    list_display = ('id','is_active','email','fullname','identity','phone','document_image','profile_image','type_user','is_admin')
    list_filter = ('is_admin',)
    list_per_page=10

    fieldsets = (
        ('User Credentials', {'fields': ('email', 'password')}),
        ('Personal info', {'fields': ('is_active','fullname','identity','phone','document_image','profile_image','type_user')}),
        ('Permissions', {'fields': ('is_admin',)}),
    )
    # add_fieldsets is not a standard ModelAdmin attribute. UserModelAdmin
    # overrides get_fieldsets to use this attribute when creating a user.
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'fullname','identity','phone','type_user','document_image','profile_image', 'password1', 'password2'),
        }),
    )
    search_fields = ('email',)
    ordering = ('email','id')
    filter_horizontal = ()


# Now register the new UserModelAdmin...
admin.site.register(User, UserModelAdmin)

# ... and, since we're not using Django's built-in permissions,
# unregister the Group model from admin.

# Register your models here.
class ProductsImageInline(admin.TabularInline):
    model = Images
    fields = ['image','is_main']
    list_display=['image_tag']
    extra = 1
   
#admin.site.register(Images,ProductsImageInline)

class ProductAdmin(admin.ModelAdmin):
        list_display = ('id','uid','name','country','state','city','price','model','manufacturedate','category','brand','condition','is_publishing','is_active','is_reject','description',)
        list_filter = ('condition','is_publishing','is_active','is_reject')
        list_per_page=10
        inlines = [ProductsImageInline]

        # add_fieldsets is not a standard ModelAdmin attribute. UserModelAdmin
        # overrides get_fieldsets to use this attribute when creating a user.
       
        search_fields = ('name','description')
        ordering = ('id','updated_at','created_at','name',)
        filter_horizontal = ()

    # Now register the ...
admin.site.register(Products,ProductAdmin)

# .


     

class CategoryAdmin(admin.ModelAdmin):
      list_display = ('id','name','image','is_home')
      list_filter = ('is_home',)
      list_per_page=10

      search_fields = ('name',)
      ordering = ('name','id')
      filter_horizontal = ()

class BrandAdmin(admin.ModelAdmin):
    list_display = ('id','name','image','is_home')
    list_filter = ('is_home',)
    list_per_page=10

    search_fields = ('name',)
    ordering = ('name','id')
    filter_horizontal = ()


# Register your models here.
admin.site.register(Categories,CategoryAdmin)
admin.site.register(Brands,BrandAdmin)

class ServicesAdmin(admin.ModelAdmin):
    list_display = ('id','name')
    list_per_page=10
    filter_horizontal = ()


class UserServicesAdmin(admin.ModelAdmin):
    list_display = ('id','uid','services','bio')
    list_filter = ('uid','services',)
    list_per_page=10
    filter_horizontal = ()

class WorkersAdmin(admin.ModelAdmin):

    list_display = ('id','name')
    list_per_page=10
    filter_horizontal = ()
     
     

admin.site.register(Workers,WorkersAdmin )
admin.site.register(Services,ServicesAdmin )
admin.site.register(Userservices,UserServicesAdmin)
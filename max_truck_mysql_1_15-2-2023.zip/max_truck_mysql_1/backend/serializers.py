from rest_framework import serializers
from backend.models import User,Messages,Workers,Services,Userservices,HistorySearch,Notification,Askorder,Categories,Subcatgoriess,Brands,Images,Products,Country,State,City,Contactus,Currency,Follow,Favorite,Application
from django.utils.encoding import smart_str, force_bytes, DjangoUnicodeDecodeError
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from backend.utils import Util
from .handle_images import compress_image
from fcm_django.models import FCMDevice

class MessagingSerializer(serializers.Serializer):
    title = serializers.CharField(required=True)
    body = serializers.CharField(required=True)
    token = serializers.CharField(required=True)
    
class CountrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Country
        fields = '__all__'


class StateSerializer(serializers.ModelSerializer):
    class Meta:
        model = State
        fields = '__all__'


class CitySerializer(serializers.ModelSerializer):
    class Meta:
        model = City
        fields = '__all__'

#-----------------------------
  
#---------------------------
class FavoritSerializer(serializers.ModelSerializer):
  class Meta:
    model=Favorite
    fields=("pid","uid","is_fav")  
    
class FollowSerializer(serializers.ModelSerializer):
  class Meta:
    model=Favorite
    fields=("uid","fuid","is_follow")  
     
class ImagesSerializer(serializers.ModelSerializer):
  class Meta:
    model = Images
    fields = ("id", "image","is_main", "product")

class ProductSerializer(serializers.ModelSerializer):

      class Meta:
        model = Products
        fields = "__all__"

class UserProductProfileSerializer(serializers.ModelSerializer):
  class Meta:
    model = User
    fields = ['id', 'fullname','profile_image','phone','code']

class WorkersSerializer(serializers.ModelSerializer):

  class Meta:
    model=Workers
    fields = '__all__'

class WorkersUsersSerializer(serializers.ModelSerializer):
  services=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Services.objects.all())
  workers=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Workers.objects.all())
  uid= UserProductProfileSerializer(many=False)
  class Meta:
    model=Userservices
    fields = ['id','workers','uid','bio','services']


class ServicesSerializer(serializers.ModelSerializer):

  class Meta:
    model=Services
    fields = '__all__'

class ServicesUsersSerializer(serializers.ModelSerializer):
  services=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Services.objects.all())
  workers=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Workers.objects.all())

  uid= UserProductProfileSerializer(many=False)

  class Meta:
    model=Userservices
    fields = ['id','services','uid','bio','workers']
 
class ServicesUserSerializer(serializers.ModelSerializer):


  class Meta:
    model=Userservices
    fields = '__all__'

class FollowSerializer(serializers.ModelSerializer):

  class Meta:
    model=Follow
    fields = '__all__'

class UserFolowProfileSerializer(serializers.ModelSerializer):
  follow_from = FollowSerializer(many=True)
  # is_follow = serializers.IntegerField(source='follow_from.count',  read_only=True)
  #follow_to = FollowSerializer(many=True)
 # is_follow = serializers.IntegerField(source='follow_to.count',  read_only=True)
  # is_follow = serializers.BooleanField()

  class Meta:
    model = User
    fields = ['follow_from', 'fullname','profile_image','phone','code']


class FollowToUserSerializer(serializers.ModelSerializer):
  fuid=UserProductProfileSerializer(many=False)
  

  class Meta:
    model=Follow
    fields = '__all__'  

class FollowFromUserSerializer(serializers.ModelSerializer):
  uid= UserProductProfileSerializer(many=False)
  

  class Meta:
    model=Follow
    fields = '__all__'  

class ProductFavsSerializer(serializers.ModelSerializer):
      images =ImagesSerializer(many=True)
    #  favs = FavoritSerializer(many=True)
    #  uid= UserProductProfileSerializer(many=False)
      is_fav = serializers.BooleanField()
      category=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Categories.objects.all())
      brand=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Brands.objects.all())
      country=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
      state=serializers.SlugRelatedField(many=False, slug_field="state",queryset=State.objects.all())
      city=serializers.SlugRelatedField(many=False, slug_field="city",queryset=City.objects.all())
      manufacturcountry=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
      currency=serializers.SlugRelatedField(many=False, slug_field="currency_symbol",queryset=Country.objects.all())
      countimg=len(images.data)
      if is_fav == "Null" :is_fav=0
      #if is_fav!=1 : is_fav=0
      #is_fav=is_fav.fillna(0, inplace = True)
      class Meta:
        model = Products
        fields = ('id','name','uid',  'is_fav','images','description','country','state','city','category','brand','price','currency','model','manufacturedate','manufacturcountry','condition','created_at','updated_at','type_for','is_active')
class ProductsFollowSerializer(serializers.ModelSerializer):
        images =ImagesSerializer(many=True)
        favs = FavoritSerializer(many=True)
        uid= UserProductProfileSerializer(many=False)
        is_fav = serializers.IntegerField(source='favs.count',  read_only=True)
        category=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Categories.objects.all())
        brand=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Brands.objects.all())
        country=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
        state=serializers.SlugRelatedField(many=False, slug_field="state",queryset=State.objects.all())
        city=serializers.SlugRelatedField(many=False, slug_field="city",queryset=City.objects.all())
        manufacturcountry=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
        currency=serializers.SlugRelatedField(many=False, slug_field="currency_symbol",queryset=Country.objects.all())
        class Meta:
          model = Products
          fields = ('uid','id','name', 'is_fav','images','description','country','state','city','category','brand','price','currency','model','manufacturedate','manufacturcountry','condition','created_at','updated_at','type_for','is_active','favs')


class ProductsSerializer(serializers.ModelSerializer):
      images =ImagesSerializer(many=True)
      favs = FavoritSerializer(many=True)
     

      uid= UserProductProfileSerializer(many=False)
      is_fav = serializers.IntegerField(source='favs.count',  read_only=True)
      category=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Categories.objects.all())
      brand=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Brands.objects.all())
      country=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
      state=serializers.SlugRelatedField(many=False, slug_field="state",queryset=State.objects.all())
      city=serializers.SlugRelatedField(many=False, slug_field="city",queryset=City.objects.all())
      manufacturcountry=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
      currency=serializers.SlugRelatedField(many=False, slug_field="currency_symbol",queryset=Country.objects.all())
      countimg=len(images.data)
    #  if is_fav>0: is_fav=1
      class Meta:
        model = Products
        fields = ('uid','id','name', 'is_fav','images','description','country','state','city','category','brand','price','currency','model','manufacturedate','manufacturcountry','condition','created_at','updated_at','type_for','is_active','favs')




class ProductDetailSerializer(serializers.ModelSerializer):
    uid=serializers.SlugRelatedField(many=False, slug_field="fullname",queryset=User.objects.all())
    category=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Categories.objects.all())
    brand=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Brands.objects.all())
    country=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
    state=serializers.SlugRelatedField(many=False, slug_field="state",queryset=State.objects.all())
    city=serializers.SlugRelatedField(many=False, slug_field="city",queryset=City.objects.all())

    class Meta:
        model = Products
        fields = "__all__"
       # fields = ('id', 'name','location','price','type_for','is_active','description','image','user_name', 'brand_name','category_name','subcategory_name')

class ProductFavSerializer(serializers.ModelSerializer):
      images =ImagesSerializer(many=True)
      favs = FavoritSerializer(many=True)
      is_fav = serializers.IntegerField(source='favs.count',  read_only=True)
      category=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Categories.objects.all())
      brand=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Brands.objects.all())
      country=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
      state=serializers.SlugRelatedField(many=False, slug_field="state",queryset=State.objects.all())
      city=serializers.SlugRelatedField(many=False, slug_field="city",queryset=City.objects.all())
      manufacturcountry=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
      currency=serializers.SlugRelatedField(many=False, slug_field="currency_symbol",queryset=Country.objects.all())
      class Meta:
        model = Products
        fields = ('uid','id','is_fav','name', 'description','images','country','state','city','category','brand','price','currency','model','manufacturedate','manufacturcountry','condition','is_active','is_publishing','type_for','favs')

class ApplicationSerializer(serializers.ModelSerializer):
  class Meta:
    model=Application
    fields="__all__"    

class CountrySerializerProduct(serializers.ModelSerializer):
  country=serializers.SlugRelatedField(many=False, slug_field="country",queryset=Country.objects.all())
  class Meta:
    model=Products
    fields = (
            "country",
          )
class StateSerializerProduct(serializers.ModelSerializer):
  state=serializers.SlugRelatedField(many=False, slug_field="state",queryset=State.objects.all())
  class Meta:
    model=Products
    fields = (
            "state",
          )          

class CitySerializerProduct(serializers.ModelSerializer):
  city=serializers.SlugRelatedField(many=False, slug_field="city",queryset=City.objects.all())
  class Meta:
    model=Products
    fields = (
            "city",
          )  

class CategorySerializerProduct(serializers.ModelSerializer):
  category=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Categories.objects.all())
  class Meta:
    model=Products
    fields = (
            "category",
          ) 
class SubcategorySerializerProduct(serializers.ModelSerializer):
  subcategory=serializers.SlugRelatedField(many=False, slug_field="name",queryset=Subcatgoriess.objects.all())
  class Meta:
    model=Products
    fields = (
            "subcategory",
          )           

class BrandSerializer(serializers.ModelSerializer):
  brand=serializers.SlugRelatedField(many=False,slug_field="name",queryset=Brands.objects.all())
  class Meta:
    model=Products
    fields = (
            "brand",
          )
class modelSerializer(serializers.ModelSerializer):
  class Meta:
    model=Products
    fields=(
      "model",
    )
class ContactusSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contactus
        fields = '__all__'
  
class CurrencySerializer(serializers.ModelSerializer):
    class Meta:
        model = Currency
        fields = ('id','code','name')
class CategoryNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = Categories
        fields = ('id','name','image','is_home')
        
class BrandNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = Brands
        fields = ('id','name','image','is_home')

class SubcatListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subcatgoriess
        fields = ('id', 'name','image')

class CatDetailSerializer(serializers.ModelSerializer):
    cats = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Subcatgoriess
        fields = ('id', 'name',  'cats','image','is_home')

'''
          ####Users 
'''

class FCMDeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = FCMDevice
        fields = ['name', 'device_id', 'registration_id', 'type','user']


        
class UserRegistrationSerializer(serializers.ModelSerializer):
  # We are writing this becoz we need confirm password field in our Registratin Request
  password2 = serializers.CharField(style={'input_type':'password'}, write_only=True)
  class Meta:
    model = User
    fields=['email', 'fullname','identity','phone','code','type_user','document_image','profile_image', 'password', 'password2']
    extra_kwargs={
      'password':{'write_only':True}
    }

  # Validating Password and Confirm Password while Registration
  def validate(self, attrs):
    password = attrs.get('password')
    password2 = attrs.get('password2')
    if password != password2:
      raise serializers.ValidationError("Password and Confirm Password doesn't match")
    return attrs

  def create(self, validate_data):
    return User.objects.create_user(**validate_data)

class UserLoginSerializer(serializers.ModelSerializer):
  email = serializers.EmailField(max_length=255)
  class Meta:
    model = User
    fields = ['email', 'password']

class UserChangePasswordSerializer(serializers.Serializer):
  password = serializers.CharField(max_length=255, style={'input_type':'password'}, write_only=True)
  password2 = serializers.CharField(max_length=255, style={'input_type':'password'}, write_only=True)
  class Meta:
    fields = ['password', 'password2']

  def validate(self, attrs):
    password = attrs.get('password')
    password2 = attrs.get('password2')
    uid = self.context.get('uid')
    user = self.context.get('user')
    if password != password2:
      raise serializers.ValidationError("Password and Confirm Password doesn't match")
    user.set_password(password)
    user.save()
    return attrs

class UserProfileSerializer(serializers.ModelSerializer):
  class Meta:
    model = User
    fields = ['id', 'email', 'fullname','identity','phone','document_image','profile_image','type_user']
class UserActiveSerializer(serializers.ModelSerializer):
  class Meta:
    model = User
    fields = '__all__'      
class SendPasswordResetEmailSerializer(serializers.Serializer):
  email = serializers.EmailField(max_length=255)
  class Meta:
    fields = ['email']

  def validate(self, attrs):
    email = attrs.get('email')
    if User.objects.filter(email=email).exists():
      user = User.objects.get(email = email)
      uid = urlsafe_base64_encode(force_bytes(user.id))
      #print('Encoded UID', uid)
      token = PasswordResetTokenGenerator().make_token(user)
      #print('Password Reset Token', token)
      link = 'http://localhost:3000/api/user/reset/'+uid+'/'+token
      #print('Password Reset Link', link)
      # Send EMail
      body = 'Click Following Link to Reset Your Password '+link
      data = {
        'subject':'Reset Your Password',
        'body':body,
        'to_email':user.email
      }
      Util.send_email(data)
      return attrs
    else:
      raise serializers.ValidationError('You are not a Registered User')

class UserPasswordResetSerializer(serializers.Serializer):
  password = serializers.CharField(max_length=255, style={'input_type':'password'}, write_only=True)
  password2 = serializers.CharField(max_length=255, style={'input_type':'password'}, write_only=True)
  class Meta:
    fields = ['password', 'password2']

  def validate(self, attrs):
    try:
      password = attrs.get('password')
      password2 = attrs.get('password2')
      uid = self.context.get('uid')
      token = self.context.get('token')
      if password != password2:
        raise serializers.ValidationError("Password and Confirm Password doesn't match")
      id = smart_str(urlsafe_base64_decode(uid))
      user = User.objects.get(id=id)
      if not PasswordResetTokenGenerator().check_token(user, token):
        raise serializers.ValidationError('Token is not Valid or Expired')
      user.set_password(password)
      user.save()
      return attrs
    except DjangoUnicodeDecodeError as identifier:
      PasswordResetTokenGenerator().check_token(user, token)
      raise serializers.ValidationError('Token is not Valid or Expired')
class MessageSerializer(serializers.ModelSerializer):

    class Meta:
        model = Messages
        fields = ['id','sender', 'receiver','message', 'timestamp']
class MessagesSerializer(serializers.ModelSerializer):
    sender= UserProductProfileSerializer(many=False)

    class Meta:
        model = Messages
        fields = ['id','sender', 'receiver','message', 'timestamp']
class AskorderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Askorder
        fields = ['id','sender', 'receiver','product' ,'subject','count','message','from_date','to_date', 'timestamp','parent']

class UserAskorderSerializer(serializers.ModelSerializer):

    sender= UserProductProfileSerializer(many=False)
    receiver= UserProductProfileSerializer(many=False)
    product=ProductsSerializer(many=False)
    reply_parent = AskorderSerializer(many=True)

    class Meta:
      model = Askorder
      fields = ['id','sender', 'receiver','subject','product' ,'count','message','from_date','to_date', 'timestamp','parent','reply_parent']


class AskorderReplySerializer(serializers.ModelSerializer):
    contact_parent = AskorderSerializer(many=True)
    
    class Meta:
        model = Askorder
        fields = [..., "Askorder"]


class NotifSerializer(serializers.ModelSerializer):
 

    class Meta:
        model = Notification
        fields = ['uid','is_seen', 'message','pub_date','duration' ]
    
class UserNotificationSerializer(serializers.ModelSerializer):

  class Meta:
      model = Notification
      fields = '__all__'      



class HistorySearchSerializer(serializers.ModelSerializer):
 

    class Meta:
      model = HistorySearch
      fields = '__all__'      
    
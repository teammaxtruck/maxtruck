from django.urls import path
from django.urls import re_path as url 
from django.conf.urls import include
 
from rest_framework.routers import DefaultRouter
from backend.views import UserDeleteAccountView,UserProfileView, UserLoginView,UserRegistrationView,UserChangePasswordView,CategoryListAPIView,CategoryHomeAPIView,SendPasswordResetEmailView,UserPasswordResetView
from backend.views import (ContactusListAPIView,
                            MyContactUsApiView,
                            CurrencyListView,
                            CountryListView,
                            BrandsHomeAPIView,
                            BrandListAPIView,
                            ServicesHomeAPIView,
                            ServicesExplorAPIView,
                            ProductsListAPIView,
                            ImagesListAPIView,
                            ProudactCategoryListAPIView,
                            ProudactBrandListAPIView,
                            MyModelViewSet,
                            StateListView,
                            CityListView,
                            SearchFilterAPIVIEW,
                            SearchDescriptionAPIVIEW,
                            MyproductsApiView,
                            MyproductsActiveApiView,
                            MyproductsDisActiveApiView,
                            MyproductsRejectApiView,
                            MyproductsPendingApiView,
                            MyproductsTypeForApiView,
                            WorkerHomeAPIView,
                            ExploreAPIView,
                            MyproductAPIView,
                            HistoryApiView,
                            favoritApiView,
                            followApiView,
                            SubcategoryListview,
                            ApplicationViewApi,
                            CountryApiView,
                            StateApiView,
                            CatListView,
                            BrandListView,
                            SendSendReceiveMessageView,
                            MynotifsApiView,
                            AskorderApiView,
                            AsktoorderApiView,
                            AsktoorderReplyApiView,
                            followtousersApiView,
                            followfromusersApiView,
                            followtoUserProdApiView,
                            MyUserFollowAPIView,
                            UserProductsFollow,
                            UserProductsFeed,
                            IFUserFollowAPIView,
                            save_fcmdevice
                            
                            
)


router = DefaultRouter()
urlpatterns = [
 
    path('', include(router.urls)), 
    path('register/', UserRegistrationView.as_view(), name='register'),
    path('login/', UserLoginView.as_view(), name='login'),
    path('profile/', UserProfileView.as_view(), name='profile'),
    path('profile/update/', UserProfileView.as_view(), name='Edit Profile'),
    path('profile/delete/', UserDeleteAccountView.as_view(), name='Delete Account'),
    path('users/following/',MyUserFollowAPIView.as_view(),name='for follow users'), 
    path('users/isfollowing/',IFUserFollowAPIView.as_view(),name='is follow users'), 
    path('register/worker/', WorkerHomeAPIView.as_view(), name='get type worker '),

    
    path('following/',followApiView.as_view(),name='follow'), 
    path('followingcount/',followApiView.as_view(),name='count follow'), 
    path('followingtouser/',followtousersApiView.as_view(),name=' follow to'),
    path('followingfromuser/',followfromusersApiView.as_view(),name=' follow from'), 
    path('user/products/follow/<int:user_id>', UserProductsFollow.as_view(), name='Profile-user_follow'),
    path('product/followusr/<int:puid>', followtoUserProdApiView.as_view(), name='Products-user_follow'),
    path('product/feeds/', UserProductsFeed.as_view(), name='Products-user_feed'),

    
    path('changepassword/', UserChangePasswordView.as_view(), name='changepassword'),
    path('send-reset-password-email/', SendPasswordResetEmailView.as_view(), name='send-reset-password-email'),
    path('reset-password/<uid>/<token>/', UserPasswordResetView.as_view(), name='reset-password'),
    path('currency/', CurrencyListView.as_view(), name='currency-home'),
    path('cathome/', CategoryHomeAPIView.as_view(), name='category-home'),
    path('categories/', CategoryListAPIView.as_view(), name='category-list'),
    path('categorieslist/', CatListView.as_view(), name='category-list'),
    path('brandslist/', BrandListView.as_view(), name='category-list'),
    path('brands/',BrandListAPIView.as_view(), name='brand-list'),
    path('brandhome/', BrandsHomeAPIView.as_view(), name='brand-home'),
    path('explorehome/', ServicesHomeAPIView.as_view(), name='explore-home'),
    path('register/services/', ServicesHomeAPIView.as_view(), name='Get Servises'),
    path('exploreuser/<int:service>', ServicesExplorAPIView.as_view(), name='Get users Servises'),

    
    

    
    path('product/create/', ProductsListAPIView.as_view(), name='Creat_Products'),
    path('productshome/', ProductsListAPIView.as_view(), name='Products-home'),
    path('product/view/<int:pro_id>', ProductsListAPIView.as_view(), name='Products-view'),
    path('product/cats/<int:cat_id>', ProudactCategoryListAPIView.as_view(), name='Products-cats_view'),
    path('product/brands/<int:brand_id>', ProudactBrandListAPIView.as_view(), name='Products-brandss_view'),
    path('product/update/<int:pro_id>', ProductsListAPIView.as_view(), name='Products-Upadte'),
    path('product/active_update/<int:pro_id>', ProductsListAPIView.as_view(), name='Products-Active_Upadte'),
    path('product/delete/<int:pro_id>', ProductsListAPIView.as_view(), name='Products-Delete'),
    path('product/images/', ImagesListAPIView.as_view(), name='Products-Add Images'),
    path('product/images/delete/<int:img_id>', ImagesListAPIView.as_view(), name='Products-Upadte delete images'),
    path('product/images/<int:img_id>', ImagesListAPIView.as_view(), name='Products-Upadte images set is_main'),


    
    path('contactus/', ContactusListAPIView.as_view(), name='post contactus'),
    path('contactus/view/<int:count_id>', ContactusListAPIView.as_view(), name='get contactus id'),
    path('contactus/delete/<int:count_id>', ContactusListAPIView.as_view(), name='delete contactus-Delete'),
    path('contactus/update/<int:count_id>', ContactusListAPIView.as_view(), name='put contactus-Upadte'),
    path('contactus/viewall/', MyContactUsApiView.as_view(), name='get '),    
    path('image/', MyModelViewSet.as_view(), name='iamge-home'),
    url(r'^countries/$', CountryListView.as_view(), name='countries'),
    # """List States            : api/states/id:country id""",
    # """Method: GET """,       """,
    url(r'^countries/(?P<id>[0-9]+)/states/$', StateListView.as_view(), name='state'),
    # """List Cities            : api/cities/id:state id""",
    # """Method: GET """,       """,
    url(r'^states/(?P<id>[0-9]+)/cities/$', CityListView.as_view(), name='city'),
    url(r'^category/(?P<id>[0-9]+)/subcategory/$', SubcategoryListview.as_view(), name='subcategory'), #finish
    path('serach/filter/',SearchFilterAPIVIEW.as_view(),name='Search Filter'), #finish
    path('searchd/',SearchDescriptionAPIVIEW.as_view(),name='Search Description'), #finish
    path('product/myproducthome/',MyproductAPIView.as_view(),name='Home Prducts'), 
    path('product/myproductexplore/',ExploreAPIView.as_view(),name='Explore Prducts'), 
    path('product/myproducts/',MyproductsApiView.as_view(),name='My Prducts'), 
    path('product/myproducts/active/',MyproductsActiveApiView.as_view(),name='Active'), 
    path('product/myproducts/disactive/',MyproductsDisActiveApiView.as_view(),name=' Dis active'), 
    path('product/myproducts/reject/',MyproductsRejectApiView.as_view(),name=' reject'), 
    path('product/myproducts/pending/',MyproductsPendingApiView.as_view(),name=' pending'), 
    path('product/myproducts/typefor/<int:type_for>/',MyproductsTypeForApiView.as_view(),name=' request rent'), 
    path('product/myproducts/typefor/<int:type_for>/',MyproductsTypeForApiView.as_view(),name=' request buy'), 
    path('history/',HistoryApiView.as_view(),name="history"), #finish
    path('product/fav/',favoritApiView.as_view(),name='favorit'), #finiish
    path('product/myfav/',favoritApiView.as_view(),name='favorit'), #finiish
    path("application/update/",ApplicationViewApi.as_view(),name="application"), #finish
    path("countryfromproducts/",CountryApiView.as_view()), #finish
    path("statefromproduct/<int:id>/",StateApiView.as_view()),#finish
    path('messages/<int:sender>/<int:receiver>', SendSendReceiveMessageView.as_view(), name='message-detail'),
    path('messages/', SendSendReceiveMessageView.as_view(), name='message-list'),
    path('asktoorder/<int:msg_id>', AsktoorderApiView.as_view(), name='Ask to order'),
    path('asktoreplyorder/<int:msg_id>', AsktoorderReplyApiView.as_view(), name='Ask to Reply order'),
    path('asktoorder/delete/<int:msg_id>', AskorderApiView.as_view(), name='delete asktoorder-Delete'),
    path('asktoorder/', AsktoorderApiView.as_view(), name='Ask to order'),
    path('askorder/', AskorderApiView.as_view(), name='Ask order'),
    path('messages/test/', SendSendReceiveMessageView.as_view(), name='message-detail'),
    path('save_fcmdevice/', save_fcmdevice),
    path('mynotif/', MynotifsApiView.as_view(), name='Notif-detail'),

    
    
     
]
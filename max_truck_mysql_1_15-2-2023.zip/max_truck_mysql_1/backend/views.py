from asgiref.sync import async_to_sync
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import generics,status
from rest_framework.views import APIView
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from backend.serializers import   UserLoginSerializer,UserRegistrationSerializer,ProductsFollowSerializer,UserProfileSerializer
from backend.serializers import   UserActiveSerializer,UserChangePasswordSerializer,UserPasswordResetSerializer,SendPasswordResetEmailSerializer
from backend.serializers import   FCMDeviceSerializer,UserFolowProfileSerializer,WorkersUsersSerializer,ServicesUsersSerializer,ServicesUserSerializer,WorkersSerializer
from backend.serializers import   ServicesSerializer,UserNotificationSerializer, UserAskorderSerializer,MessagesSerializer,MessageSerializer,AskorderSerializer,StateSerializerProduct,CountrySerializerProduct,BrandSerializer,modelSerializer,CategorySerializerProduct,SubcatListSerializer,FollowFromUserSerializer,FollowToUserSerializer,FollowSerializer,ProductFavSerializer,FavoritSerializer,ApplicationSerializer,ContactusSerializer,CurrencySerializer,CategoryNameSerializer,BrandNameSerializer,ImagesSerializer,ProductFavsSerializer,ProductSerializer,ProductsSerializer,CountrySerializer,StateSerializer,CitySerializer
from django.contrib.auth import authenticate
from backend.renderers import UserRenderer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.views import ObtainAuthToken
from django.shortcuts import get_object_or_404
from rest_framework.generics import ListAPIView
from .models import User,Userservices,Workers,Follow,Notification,Contactus,Subcatgoriess,Askorder,Messages, Categories,Brands,Services,Images,Products,Country,State,City,Currency,Application,Favorite,History
from fcm_django.models import FCMDevice
from rest_framework.pagination import  PageNumberPagination
from django.http import HttpResponse
from rest_framework import status
from django.db import connection
from django.db.models import Q
from django.db.models import Avg, Max, Min
from django.db.models.functions import Cast
from django.db.models import FloatField
from django.shortcuts import render
from rest_framework.decorators import api_view
import firebase_admin
from firebase_admin import messaging, credentials
from django.conf import settings
from rest_framework.response import Response

#cred = credentials.Certificate("creds/maxtruck-firebase-adminsdk-kutc9-818a690544.json")
#firebase_admin.initialize_app(cred)

def get_tokens_for_user(user):
  refresh = RefreshToken.for_user(user)
  return {
     # 'refresh': str(refresh),
      'token': str(refresh.access_token),
  }
#----------------------
def whenpublished(self):
        now = timezone.now()
        
        diff= now - self
        if diff==-1 :
           diff.days=0
           diff.seconds=3000
           return str("Now") + " from minutes ago"

       # print(self)
        print("------")
        print(diff)
        if diff.days == 0 and diff.seconds >= 0 and diff.seconds < 60:
            seconds= diff.seconds
            
            if seconds == 1:
                return str(seconds) +  "second ago"
            
            else:
                return str(seconds) + " seconds ago"

            

        if diff.days == 0 and diff.seconds >= 60 and diff.seconds < 3600:
            minutes= math.floor(diff.seconds/60)

            if minutes == 1:
                return str(minutes) + " minute ago"
            
            else:
                return str(minutes) + " minutes ago"



        if diff.days == 0 and diff.seconds >= 3600 and diff.seconds < 86400:
            hours= math.floor(diff.seconds/3600)

            if hours == 1:
                return str(hours) + " hour ago"

            else:
                return str(hours) + " hours ago"

        # 1 day to 30 days
        if diff.days >= 1 and diff.days < 30:
            days= diff.days
        
            if days == 1:
                return str(days) + " day ago"

            else:
                return str(days) + " days ago"

        if diff.days >= 30 and diff.days < 365:
            months= math.floor(diff.days/30)
            

            if months == 1:
                return str(months) + " month ago"

            else:
                return str(months) + " months ago"


        if diff.days >= 365:
            years= math.floor(diff.days/365)

            if years == 1:
                return str(years) + " year ago"

            else:
                return str(years) + " years ago"


#def initialize_firebase_admin_sdk():
   #cred = credentials.Certificate(settings.FIREBASE_CERTIFICATE)
   # cred = credentials.Certificate("creds/maxtruck-firebase-adminsdk-kutc9-818a690544.json")
    #default_app = firebase_admin.initialize_app(cred)
 #   print(default_app)
   # firebase_admin.get_app()
from django.conf import settings

permission_classes = (IsAuthenticated,)
@api_view(['POST'])
def save_fcmdevice(request):
    request.data._mutable = True
    request.data['user'] = request.user.id
    request.data._mutable = False
    name = request.data['name'] if 'name' in request.data else None
    device_id = request.data['device_id'] if 'device_id' in request.data else None
    user_id = request.data['user'] if 'user_id' in request.data else None
    registration_id = request.data['registration_id'] if 'registration_id' in request.data else None
    type = request.data['type'] if 'type' in request.data else None
    registration_tokens = list(FCMDevice.objects.filter(device_id=device_id).values_list('registration_id', flat=True))
    if not registration_id in registration_tokens:
        serializer = FCMDeviceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'success': True, 'response': {'message': serializer.data},'uid':request.data['user']},
                    status=status.HTTP_201_CREATED)
        else:
            return Response({'success': False, 'response': {'message': serializer.errors}},
                    status=status.HTTP_400_BAD_REQUEST)
    else:
        return Response({'success': False, 'response': {'message': 'Device already registered.'}},
                status=status.HTTP_400_BAD_REQUEST)



class CurrencyListView(generics.ListAPIView):

   def get(self, request, format=None):
    sql='SELECT * FROM backend_currency'
    queryset = Currency.objects.raw(sql)
    serializer = CurrencySerializer(queryset, many=True)
    counts=len(serializer.data)
    expected_data = {
              "count":counts,
              "Currencies":serializer.data ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)
class CountryListView(generics.ListAPIView):

   def get(self, request, format=None):
    queryset =Country.objects.all()
    serializer = CountrySerializer(queryset, many=True)
    theData= serializer.data
    counts=len(serializer.data)
    expected_data = {
            # "count_page":count_page,
              "count":counts,
              "Countries":serializer.data ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)


class StateListView(generics.ListAPIView):
    serializer_class = StateSerializer
    queryset = State.objects.all()
    def list(self, request, *args, **kwargs):
        country_id = self.kwargs['id']
        country = get_object_or_404(Country, id=country_id)
        state = State.objects.filter(country_id=country.id)
        ser = StateSerializer(state, many=True).data
        counts=len(ser)
        expected_data = {
              "count":counts,
              "States":ser ,}
        json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
        return Response(json_data, status=status.HTTP_200_OK)
        #return Response(ser, status=status.HTTP_200_OK)


class CityListView(generics.ListAPIView):
    serializer_class = CitySerializer
    queryset = State.objects.all()

    def list(self, request, *args, **kwargs):
        state_id = self.kwargs['id']
        state = get_object_or_404(State, id=state_id)
        city = City.objects.filter(state_id=state.id)
        ser = CitySerializer(city, many=True).data
        counts=len(ser)
        expected_data = {
              "count":counts,
              "Cities":ser ,}
        json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
        return Response(json_data, status=status.HTTP_200_OK)

class MyModelViewSet(APIView):
   def post(self, request, format=None):
    serializer = CategoryNameSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    mymodel = serializer.save()
    json_data = {
      "code" : 200,
      "message" : "success",
       "data" :request.data
       }
    return Response(json_data, status=status.HTTP_200_OK)
class UserRegistrationView(APIView):
  # renderer_classes = [UserRenderer]

  def post(self, request, format=None):
    type_user=request.data['type_user']
    worker=request.data['worker']
    service=request.data['service']
    t1=1
    t2=2
    if int(type_user)==2: service=t2
    if int(type_user)==1 : worker=service
    serializer = UserRegistrationSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    user = serializer.save()
    if serializer.is_valid():
       last_id =user.id
       servicesw = Userservices.objects.create(uid_id=last_id,type_user=type_user,services_id=service,workers_id=worker)
    token = get_tokens_for_user(user)
    #token,created=Token.objects.get_or_create(user=user)
    image='images/users/person.png'
    expected_data = {
            "service":service,
            "worker":worker,
            "type_user":type_user,
            "token":token,
            "uid":user.id,
            "name":user.fullname,
            "email":user.email,
            "profile_image":image
            }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)


class UserLoginView(APIView):
  renderer_classes = [UserRenderer]
  def post(self, request, format=None):
   
    #request.data['email']=request.data['email'].lower()
    serializer = UserLoginSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    email = serializer.data.get('email')
    password = serializer.data.get('password')
    user = authenticate(email=email, password=password)
    if user is not None:
        #token,created=Token.objects.get_or_create(user=user)
        token = get_tokens_for_user(user)
        image='images/users/person.png'
        expected_data = {
                      "token":token,
                      "uid":user.id,
                      "fullname":user.fullname,
                      "image" :"media/"+image}

        json_data = {
                "code" : 200,
                "message" : "success",
                "data" :expected_data
                }
        return Response(json_data, status=status.HTTP_200_OK)

              # return Response({'code':200,'msg':'success','data':token},status=status.HTTP_200_OK)
    else:
          return Response({'errors':{'non_field_errors':['Email or Password is not Valid']}}, status=status.HTTP_404_NOT_FOUND)

class UserDeleteAccountView(APIView):
     permission_classes = [IsAuthenticated]
     def put(self, request, *args, **kwargs):
        '''
        Deletes the products item with given id if exists
        ''' 
        '''
         '''
        uid =request.user
        if not uid:
            return Response(
                {"res": "Object with Users id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        data = {
            'fullname': request.data.get('fullname'),
            'identity': request.data.get('identity'),
            'phone': request.data.get('phone'),
            'document_image': request.data.get('document_image'),
            'profile_image':  request.data.get('profile_image'),
            'services': request.data.get('services'),
            'pio':request.data.get('pio'),

        }
        serializer = UserActiveSerializer(instance = uid, data={'is_active':0}, partial = True)
        activeproducts=Products.objects.filter(uid=uid.id)
        serializerp = ProductSerializer(instance = activeproducts, data = {'is_active':0}, partial = True)
        userservices=Userservices.objects.filter(uid=uid.id)
        serializerServ=ServicesUserSerializer(instance = userservices, data=request.data, partial = True)
        if serializer.is_valid():serializer.save()
        if   serializerp.is_valid() :
            serializer.save()
            json_data = {
            "uid.id":uid.id,
            "code" : 200,
            "message" : "success",
            "data" :serializerp.data
           }
            return Response(json_data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

       
      
class UserChangePasswordView(APIView):
  renderer_classes = [UserRenderer]
  permission_classes = [IsAuthenticated]
  def post(self, request, format=None):
    serializer = UserChangePasswordSerializer(data=request.data, context={'user':request.user})
    serializer.is_valid(raise_exception=True)
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :'msg :Password Changed Successfully'
        }
    return Response(json_data, status=status.HTTP_200_OK)


class UserProductsFollow(APIView):
  def get(self, request, user_id, *args, **kwargs):
    uid=request.user.id
    sql='Select f.is_fav,j.* from backend_products j left JOIN  backend_favorite f on j.id = f.pid_id '
    sql=sql+'  AND f.uid_id=%(uid)s '
    sql=sql+'  WHERE ( j.is_active=1 And j.is_publishing=1 AND j.uid_id=%(user_id)s )  ORDER BY j.id desc  '
    params={"uid":uid,'user_id':user_id}
    queryset = Products.objects.raw(sql,params)
    serializer=ProductFavsSerializer(queryset,many=True)
    follows=Follow.objects.filter(uid=user_id)
    followers=Follow.objects.filter(fuid=user_id)
    f=False
    for i in range(len(follows)):
       if follows[i].fuid_id==uid : f=True

    ff=False
    for i in range(len(followers)):
       if followers[i].uid_id==uid : ff=True
    
    user=User.objects.filter(id=user_id)
    userserializer=UserProfileSerializer(user,many=True).data
   
    json_data = {
          "code" : 200,
          "message" : "success",
          "user":userserializer,
          "following":f,
          "count Following":len(follows),
          "follower":ff,
          "count Follower" : len(followers),
          "count Products" : len(serializer.data),
          "data" :serializer.data
          };
    return Response(json_data, status=status.HTTP_200_OK)



class UserProductsFeed(APIView):
  def get(self, request, *args, **kwargs):
    uid=request.user.id
    sql='Select f.is_fav,j.* from backend_products j left JOIN  backend_favorite f on j.id = f.pid_id  AND f.uid_id=%(uid)s '
    sql=sql+'  WHERE ( j.is_active=1 And j.is_publishing=1 AND j.uid_id IN (SELECT fo.fuid_id FROM backend_follow fo WHERE fo.uid_id=%(uid)s))  ORDER BY j.id desc  '
    params={"uid":uid}
    queryset = Products.objects.raw(sql,params)
    serializer=ProductsFollowSerializer(queryset,many=True)
    count_all=len(serializer.data)
    page_query_param = 'page'
    page_size = 10
    paginator = PageNumberPagination()
    paginator.page_size = page_size
    paginator.page_query_param = page_query_param

    zero=len(serializer.data)%10
    count_page=round(len(serializer.data)/10)
    if zero!=0 and count_all>10 : count_page=count_page+1
    p = paginator.paginate_queryset(queryset, request=request) # change 1
    serializer = ProductsFollowSerializer(p, many=True)
    counts=len(serializer.data)
    

    expected_data = {
              "count_all":count_all,
             "count_page":count_page,
              "count":counts,
              "data":serializer.data ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }

    return Response(json_data, status=status.HTTP_200_OK)



class UserProfileView(APIView):
  renderer_classes = [UserRenderer]
  permission_classes = [IsAuthenticated]
  def get(self, request, format=None):
    serializer = UserProfileSerializer(request.user)
    uid=request.user.id
    count_follow_to=Follow.objects.filter(uid_id=uid).count()
    count_follow_me=Follow.objects.filter(fuid_id=uid).count()
    json_data = {
            "code" : 200,
            "message" : "success",
            "count_follow_to":count_follow_to,
            "count_follow_me ":count_follow_me,
            "data" :serializer.data
           }
    return Response(json_data, status=status.HTTP_200_OK)
  def put(self, request, *args, **kwargs):
        '''
         '''
        uid =request.user
      
        if not uid:
            return Response(
                {"res": "Object with Users id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        data = {
            'fullname': request.data.get('fullname'),
            'identity': request.data.get('identity'),
            'phone': request.data.get('phone'),
            'document_image': request.data.get('document_image'),
            'profile_image':  request.data.get('profile_image'),
           # 'type_user': request.data.get('type_user'),

        }
        serializer = UserProfileSerializer(instance = uid, data=data, partial = True)
        if serializer.is_valid():
           serializer.save()
           json_data = {
            "code" : 200,
            "message" : "success",
            "data" :serializer.data
           }
           return Response(json_data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class SendSendReceiveMessageView(APIView):
  permission_classes = [IsAuthenticated]

  def get(self, request, sender=None, receiver=None):
        receiver=request.user
        messages = Messages.objects.filter(receiver_id=receiver)
        serializer = MessagesSerializer(messages, many=True, context={'request': request})
       # for message in messages:
        #    message.is_read = True
         #   message.save()

        return JsonResponse(serializer.data, safe=False)

  def post(self, request, sender=None, receiver=None):
         sender1=request.user
         fullname=sender1.fullname
         serializer = MessageSerializer(data=request.data)
         receiver = request.data.get('receiver')
         MDevic=FCMDevice.objects.filter(user=receiver,active=1)
         token=MDevic[0].registration_id
         notification = messaging.Notification(title=fullname,body=" Message from ",)
         message = messaging.Message(notification=notification,token=token,)
         messaging.send(message)
         Notif = Notification.objects.create(uid_id=receiver, is_seen=0,message="From "+ fullname)

         if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
         return JsonResponse(serializer.errors, status=400)

class SendPasswordResetEmailView(APIView):
  renderer_classes = [UserRenderer]
  def post(self, request, format=None):
   

    serializer = SendPasswordResetEmailSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    return Response({'msg':'Password Reset link send. Please check your Email'}, status=status.HTTP_200_OK)

class UserPasswordResetView(APIView):
  #renderer_classes = [UserRenderer]
  def post(self, request, uid, token, format=None):
    serializer = UserPasswordResetSerializer(data=request.data, context={'uid':uid, 'token':token})
    serializer.is_valid(raise_exception=True)
    return Response({'msg':'Password Reset Successfully'}, status=status.HTTP_200_OK)

  ###########cats_View
class CatListView(generics.ListAPIView):

   def get(self, request, format=None):
    queryset =Categories.objects.all()
    serializer = CategoryNameSerializer(queryset, many=True)
    counts=len(serializer.data)
    expected_data = {
              "count":counts,
              "Categories":serializer.data ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)
class BrandListView(generics.ListAPIView):

   def get(self, request, format=None):
    queryset =Brands.objects.all()
    serializer = BrandNameSerializer(queryset, many=True)
    counts=len(serializer.data)
    expected_data = {
              "count":counts,
              "Brands":serializer.data ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)
class MyContactUsApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self,request,format=None):
    uid=request.user
    contact= Contactus.objects.filter(uid=uid.id).order_by('-id')
    serializer = ContactusSerializer(contact, many=True)
    counts=len(serializer.data)
    expected_data = {
           "count":counts,
            "My contacts ":serializer.data ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)
class ContactusListAPIView(APIView):
   permission_classes = [IsAuthenticated]
   def post(self, request, format=None):
   # request.data['uid'] = request.user.id
    serializer = ContactusSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()

        json_data = {
                "code" : 200,
                "Uid": request.user.id,
                "message" : "success",
                "Data":serializer.data

                }

        return Response(json_data, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # if there is something in items else raise error
   def get_object(self, cont_id):
        '''
        Helper method to get the object with given cont_id
        '''
        try:
            return Contactus.objects.get(id=cont_id )
        except Contactus.DoesNotExist:
            return None

    # 3. Retrieve
   def get(self, request, count_id, *args, **kwargs):
        '''
        Retrieves the Contactus with given Contactusd
        '''
        prod_instance = self.get_object(count_id)
        if not prod_instance:
            return Response(
                {"res": "Object with proudcts id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = ContactusSerializer(prod_instance)

        json_data = {
      "code" : 200,
      "message" : "success",
      "data":serializer.data,

       }

        return Response(json_data, status=status.HTTP_200_OK)

   def put(self, request, count_id, *args, **kwargs):
        '''
         '''
        prod_instance = self.get_object(count_id)
        if not prod_instance:
            return Response(
                {"res": "Object with proudcts id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        data = {
            'fullname': request.data.get('fullname'),
            'title': request.data.get('title'),
            'email': request.data.get('email'),
            'message': request.data.get('message'),
             'uid': request.user.id
        }
        serializer = ContactusSerializer(instance = prod_instance, data=data, partial = True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

       # 5. Delete
   def delete(self, request, count_id, *args, **kwargs):
        '''
        Deletes the  item with given id if exists
        '''
        prod_instance = self.get_object(count_id)
        if not prod_instance:
            return Response(
                {"res": "Object with Contactus id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        prod_instance.delete()

        return Response(
            {"res": "Object deleted!"},
            status=status.HTTP_200_OK
        )
class ImagesListAPIView(APIView):
     permission_classes = [IsAuthenticated]
     def get_object(self, img_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Images.objects.get(id=img_id )
        except Images.DoesNotExist:
            return None
     def post(self, request, format=None):
         product= request.data['product']
         files = request.FILES.getlist('image')

         if files:
           request.data.pop('image')
           uploaded_files = []
           a=0
           for file in files:
              content = Images.objects.create(product_id=product, image=file,is_main=0)
              uploaded_files.append(content)
         
           prod_instance =Products.objects.get(id=product )
           serializer = ProductsSerializer(prod_instance)
           
           json_data = {
                    "code" : 200,
                 
                    "message" : "success",
                  "products":serializer.data

                    }

           return Response(json_data, status=status.HTTP_200_OK)
         return Response("error", status=status.HTTP_400_BAD_REQUEST)


     def put(self, request, img_id, *args, **kwargs):
        img_instance =Images.objects.get(id=img_id )
        productsimg=Images.objects.filter(id=img_id)
        product= productsimg[0].product
        images=Images.objects.filter(product=product)
   
        for image in images:
           serializer = ImagesSerializer(instance = image, data = {'is_main':0}, partial = True)
           if serializer.is_valid():
                serializer.save()
        serializer = ImagesSerializer(instance = img_instance, data = {'is_main':1}, partial = True)

        if serializer.is_valid():
            serializer.save()
            json_data={
            "code" : 200,
            "message" : "success",
          "len(images)":len(images),
            }
            return Response(json_data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

         
     def delete(self, request, img_id, *args, **kwargs):
        '''
        Deletes the images item with given id if exists
        '''


        img_instance = self.get_object(img_id)
       # img_instance =Images.objects.get(id=img_id )
        if not img_instance:
            return Response(
                {"res": "Object with products id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        img_instance.delete()
        

        return Response(
            {"res": "Object deleted!"},
            status=status.HTTP_200_OK
        )

  

class ProductsListAPIView(APIView):
   permission_classes = [IsAuthenticated]
   def post(self, request, format=None):
    request.data['uid'] = request.user.id
    request.data['currency'] =233 #usa $
    uid=request.user.id
    serializer = ProductSerializer(data=request.data)
    files = request.FILES.getlist('image')
    if files:
      request.data.pop('image')

    if serializer.is_valid():
        serializer.save(uid_id=uid)
        last_id = Products.objects.get(id=serializer.data['id'])
        uploaded_files = []
        a=0
        for file in files:
          is_main=False
          a=a+1
          if a ==1 :
            is_main= True
          content = Images.objects.create(product=last_id, image=file,is_main=is_main)
          uploaded_files.append(content)


        json_data = {
                "code" : 200,
                "Uid": request.user.id,
                "message" : "success",
                "products":serializer.data

                }

        return Response(json_data, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

   
    # if there is something in items else raise error

   def get_object(self, pro_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Products.objects.get(id=pro_id )
        except Products.DoesNotExist:
            return None
   def get_images(self, pro_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Images.objects.get(product=pro_id )
        except Images.DoesNotExist:
            return None
    # 3. Retrieve
   def get(self, request, pro_id, *args, **kwargs):
      
        '''
        Retrieves the Products with given pro_id
        '''
      
        prod_instance = self.get_object(pro_id)
        if not prod_instance:
            return Response(
                {"res": "Object with proudcts id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        products=Products.objects.filter(id=pro_id)
        fuid= products[0].uid
        serializer = ProductsSerializer(prod_instance)
        uid=request.user.id
        print(fuid)
        folow=Follow.objects.filter(uid_id=uid,fuid_id=fuid).count()
        json_data = {
      "code" : 200,
      "message" : "success",
      "follow":folow,
      "products":serializer.data,
       }

        return Response(json_data, status=status.HTTP_200_OK)
   def patch(self, request, pro_id, *args, **kwargs):
        prod_instance = self.get_object(pro_id)
        activeproducts=Products.objects.filter(id=pro_id)
        if activeproducts[0].is_active==0 :
           is_active=1
        else : is_active=0
        serializer = ProductSerializer(instance = prod_instance, data = {'is_active':is_active}, partial = True)
        if serializer.is_valid():
            serializer.save()
            json_data={
            "code" : 200,
            "message" : "success",
            "Products":serializer.data
            }
            return Response(json_data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


   def put(self, request, pro_id, *args, **kwargs):
        '''
         '''
        prod_instance = self.get_object(pro_id)
        if not prod_instance:
            return Response(
                {"res": "Object with proudcts id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        data = {
            'name': request.data.get('name'),
            'price': request.data.get('price'),
            'brand': request.data.get('brand'),
            'category': request.data.get('category'),
            'price': request.data.get('price'),
            'currency': request.data.get('currency'),
            'country': request.data.get('country'),
            'state': request.data.get('state'),
            'city': request.data.get('city'),
            'type_for': request.data.get('type_for'),
            'condition': request.data.get('condition'),
            'model': request.data.get('model'),
            'description': request.data.get('description'),
            'manufacturedate': request.data.get('manufacturedate'),
            'manufacturcountry': request.data.get('manufacturcountry'),
            'uid': request.user.id
        }
        serializer = ProductSerializer(instance = prod_instance, data=data, partial = True)
        if serializer.is_valid():
              serializer.save()
        files = request.FILES.getlist('image')
        if files:
              request.data.pop('image')
              uploaded_files = []
              a=0
              for file in files:
                  is_main=False
                  a=a+1
                  if a ==1 :
                    is_main= True
                  content = Images.objects.create(product_id=pro_id, image=file,is_main=is_main)
                  uploaded_files.append(content)

              return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

       # 5. Delete

   def delete(self, request, pro_id, *args, **kwargs):
        '''
        Deletes the products item with given id if exists
        '''


        prod_instance = self.get_object(pro_id)
        if not prod_instance:
            return Response(
                {"res": "Object with products id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        #img_instance.delete()
        img_instance=Images.objects.filter(product=pro_id).delete()
        prod_instance.delete()

        return Response(
            {"res": "Object deleted!"},
            status=status.HTTP_200_OK
        )
class ProudactCategoryListAPIView(APIView):
 permission_classes = [IsAuthenticated]

 def get_object(self, cat_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Products.objects.get(category_id=cat_id )
        except Products.DoesNotExist:
            return None

 def get(self, request, cat_id, *args, **kwargs):
        '''
        Retrieves the Products with given pro_id
        '''
        uid=request.user.id
        sql=' SELECT f.is_fav, j.* from backend_products j left JOIN  backend_favorite f  on j.id = f.pid_id '
        sql=sql+' And f.uid_id=%(uid)s WHERE ( j.is_active=1 And j.is_publishing=1 ) and'
        sql=sql+'( j.category_id = %(category_id)s ) ORDER BY j.id desc '
        params={"uid":uid,'category_id':cat_id}
                  # queryset = Products.objects.filter(Q(category_id__in=cats_id) | Q(brand_id__in=brands_id)|Q(name__icontains=pattern)|Q(description__icontains=pattern),is_reject=0)
        #print(params)     
        queryset = Products.objects.raw(sql,params)
        serializer = ProductFavsSerializer(queryset, many=True).data
      #  product = Products.objects.filter(is_active=1,category=cat_id)
        if not queryset:
            return Response(
                {"res": "Object with proudcts id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        counts=len(serializer)

        json_data = {
         "code" : 200,
        "message" : "success",
        "count":counts,
        "products":serializer

        }

        return Response(json_data, status=status.HTTP_200_OK)

class ProudactBrandListAPIView(APIView):
 permission_classes = [IsAuthenticated]
 def get_object(self, brand_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Products.objects.get(brand=brand_id )
        except Products.DoesNotExist:
            return None

 def get(self, request, brand_id, *args, **kwargs):
        '''
        Retrieves the Products with given pro_id
        '''
        uid=request.user.id
        sql=' SELECT f.is_fav, j.* from backend_products j left JOIN  backend_favorite f  on j.id = f.pid_id '
        sql=sql+' And f.uid_id=%(uid)s WHERE ( j.is_active=1 And j.is_publishing=1 ) and'
        sql=sql+'( j.brand_id = %(brand_id)s ) ORDER BY j.id desc '
        params={"uid":uid,'brand_id':brand_id}
          
        queryset = Products.objects.raw(sql,params)
        serializer = ProductFavsSerializer(queryset, many=True).data
        if not queryset:
            return Response(
                {"res": "Object with proudcts id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
      #  serializer=ProductsSerializer(queryset,many=True).data
        counts=len(serializer)
      #  serializer = ProductDetailSerializer(prod_instance,many=True)
      #  counts=len(serializer.data)
        json_data = {
         "code" : 200,
        "message" : "success",
        "count":counts,
        "products":serializer

        }

        return Response(json_data, status=status.HTTP_200_OK)



class CategoryListAPIView(APIView):

    # if there is something in items else raise error
  def get(self, request, format=None):
    page_query_param = 'page'
    page_size = 10
    paginator = PageNumberPagination()
    paginator.page_size = page_size
    paginator.page_query_param = page_query_param
    cats =Categories.objects.all()
    serializer = CategoryNameSerializer(cats, many=True)
    count_all=len(serializer.data)

    zero=len(serializer.data)%10
    count_page=round(len(serializer.data)/10)
    if zero!=0 and count_all>10 : count_page=count_page+1
    p = paginator.paginate_queryset(cats, request=request) # change 1
    serializer = CategoryNameSerializer(p, many=True)
    theData= serializer.data
    counts=len(serializer.data)
    expected_data = {
              "count_all":count_all,
             "count_page":count_page,
              "count":counts,
              "Categories":serializer.data ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)


class CategoryHomeAPIView(APIView):

    # if there is something in items else raise error
  def get(self, request, format=None):
     sql='SELECT * FROM backend_categories where is_home=True'
     cats = Categories.objects.raw(sql)
     serializer = CategoryNameSerializer(cats, many=True).data
     counts=len(serializer)
     expected_data = {
            "count":counts,
            "Categories":serializer ,}
     json_data = {
      "code" : 200,
      "message" : "success",
       "data" :expected_data
       }
     return Response(json_data, status=status.HTTP_200_OK)

class BrandListAPIView(APIView):

    # if there is something in items else raise error
   def get(self, request, format=None):
    page_query_param = 'page'
    page_size = 10
    paginator = PageNumberPagination()
    paginator.page_size = page_size
    paginator.page_query_param = page_query_param
    brands =Brands.objects.all()
    serializer = BrandNameSerializer(brands, many=True)
    count_all=len(serializer.data)
    if  len(serializer.data)>10: zero=len(serializer.data)%10
    count_page=round(len(serializer.data)/10)
    if zero!=0 : count_page=count_page+1
    p = paginator.paginate_queryset(brands, request=request) # change 1
    serializer = BrandNameSerializer(p, many=True)
    theData= serializer.data
    counts=len(serializer.data)
    expected_data = {
             "count_all":count_all,
             "count_page":count_page,
              "count":counts,
              "Brands":serializer.data ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)

class BrandsHomeAPIView(APIView):

    # if there is something in items else raise error
  def get(self, request, format=None):
     sql='SELECT * FROM backend_brands where is_home=True'
     brands = Brands.objects.raw(sql)
     serializer = BrandNameSerializer(brands, many=True).data
     counts=len(serializer)
     expected_data = {
            "count":counts,
            "Brands":serializer ,}
     json_data = {
      "code" : 200,
      "message" : "success",
       "data" :expected_data
       }
     return Response(json_data, status=status.HTTP_200_OK)
class ServicesExplorAPIView(APIView):
  permission_classes = [IsAuthenticated]

  def get(self, request, service, *args, **kwargs):
   
    uid=request.user
    sql="SELECT * from backend_userservices WHERE backend_userservices.services_id=%s "
    users= Userservices.objects.raw(sql,[service])
    serializer = ServicesUsersSerializer(users, many=True)
    
    if service==0 : #all users
       sql="SELECT * from backend_userservices"
       users= Userservices.objects.raw(sql)
       serializer = ServicesUsersSerializer(users, many=True)
  
    if service==2 : #worke
       sql="SELECT * from backend_userservices WHERE backend_userservices.services_id=%s "
       users= Userservices.objects.raw(sql,[service])
       serializer = WorkersUsersSerializer(users, many=True)

     
  
    counts=len(serializer.data)
    expected_data = {
           "count":counts,
            "users":serializer.data ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)
  
class WorkerHomeAPIView(APIView):
   def get(self, request, format=None):
     workers = Workers.objects.all()
     serializer = WorkersSerializer(workers, many=True).data
     counts=len(serializer)
     expected_data = {
            "count":counts,
            "services":serializer ,}
     json_data = {
      "code" : 200,
      "message" : "success",
       "data" :expected_data
       }
     return Response(json_data, status=status.HTTP_200_OK)

class ServicesHomeAPIView(APIView):

  def post(self, request, format=None):
    serializer=ServicesUserSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    serializer.save()
    json_data = {
      "code" : 200,
      "message" : "success",
       "data":serializer.data
      }
    return Response(json_data, status=status.HTTP_200_OK)
    # if there is something in items else raise error
  def get(self, request, format=None):
     services = Services.objects.all()
     serializer = ServicesSerializer(services, many=True).data
     counts=len(serializer)
     expected_data = {
            "count":counts,
            "services":serializer ,}
     json_data = {
      "code" : 200,
      "message" : "success",
       "data" :expected_data
       }
     return Response(json_data, status=status.HTTP_200_OK)

  
class SearchFilterAPIVIEW(APIView):
  permission_classes = [IsAuthenticated]
  #def get(self,request):
  def post(self, request, format=None):
      uid=request.user.id
      category=request.data.get('category')
      brand=request.data.get('brand')
      country=request.data.get('country')
      condition=request.data.get('condition')
      model=request.data.get('model')
  

      '''
          my_dict = {'category_id': category, 'brand_id': brand, 'country_id': country,'condition':condition,'model__icontains':model}  # Your dict with fields
        #  my_dict = {k:v for k,v in my_dict.items() if v is not None}
          my_dict = {k:v for k,v in my_dict.items() if v!=""}
          product = Products.objects.filter(**my_dict)
          uid=request.user
          for i in range (len(product)):
            History.objects.create(pid=product[i],uid=uid,ctaid=product[i].category)
          serializer=ProductsSerializer(product,many=True).data
          counts=len(serializer)
      
        if t==True :
          sql=sql+'And (j.condition LIKE %(condition)s OR j.model LIKE %(model)s OR j.country_id = %(country_id)s OR j.category_id = %(category_id)s OR j.brand_id = %(brand_id)s ) ORDER BY j.id desc '
          params={"uid":uid,"condition":condition,"model":model,'country_id':country,'category_id':category,'brand_id' :brand}
          queryset = Products.objects.raw(sql,params)
        else :
          params={"uid":uid}
      #  print(sql)
      '''
      sql=' SELECT f.is_fav, j.* from backend_products j left JOIN  backend_favorite f  on j.id = f.pid_id '
      sql=sql+' And f.uid_id=%(uid)s WHERE ( j.is_active=1 And j.is_publishing=1 )  '
      if condition !="":
       sql=sql+' And (j.condition LIKE %(condition)s)'
      if model !="":
        sql=sql+'And (j.model LIKE %(model)s)'
      if category !="":
        sql=sql+'And (j.category_id = %(category_id)s)'
      if brand !="":
        sql=sql+'And (j.brand_id =%(brand_id)s)'
      if country !="":
        sql=sql+'And (j.country_id =%(country_id)s)'
      params={"uid":uid,"condition":condition,"model":model,'country_id':country,'category_id':category,'brand_id' :brand}
      queryset = Products.objects.raw(sql,params)
      serializer = ProductFavsSerializer(queryset, many=True)  
      counts=len(serializer.data)

      expected_data = {
          
            "count":counts,
            "result":serializer.data ,}
      json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
      }
      return Response(json_data, status=status.HTTP_200_OK)

class SearchDescriptionAPIVIEW(APIView):
  permission_classes = [IsAuthenticated]
  #def get(self,request):
  def post(self, request, format=None):
      pattern=request.data.get('search')

      uid=request.user.id
      brands=Brands.objects.filter(name__icontains=pattern)
      brands_id=[]
    
      for i in range(len(brands)):
        brands_id.append(brands[i].id)
      
      cats=Categories.objects.filter(name__icontains=pattern)
      cats_id=[]
    
      for i in range(len(cats)):
        cats_id.append(cats[i].id)
  
      sql=' SELECT f.is_fav, j.* from backend_products j left JOIN  backend_favorite f  on j.id = f.pid_id '
      sql=sql+' And f.uid_id=%(uid)s WHERE ( j.is_active=1 And j.is_publishing=1 ) And '
      sql=sql+'(j.name LIKE %(name)s  OR  j.description LIKE %(description)s )'
      if len(brands)!=0 : 
        sql=sql+ 'OR j.brand_id in %(brand_id)s   '
      if len(cats) !=0 :
        sql=sql+ 'OR  j.category_id IN %(category_id)s  '
      sql=sql+"ORDER BY j.id desc "
      params={"uid":uid,"name":'%'+pattern+'%',"description":'%'+pattern+'%','category_id':cats_id,'brand_id' :brands_id}
      queryset = Products.objects.raw(sql,params)
      serializer = ProductFavsSerializer(queryset, many=True)  
      counts=len(serializer.data)
      expected_data = {
           
            "count":counts,
            "result":serializer.data ,}
      json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
      }
      return Response(json_data, status=status.HTTP_200_OK)
      
# ranim
class SubcategoryListview(generics.ListAPIView):
    serializer_class = SubcatListSerializer
    queryset = Subcatgoriess.objects.all()
    def list(self, request, *args, **kwargs):
        category_id = self.kwargs['id']
        category= get_object_or_404(Categories, id=category_id)
        subcategory = Subcatgoriess.objects.filter(cats_id=category.id)
        ser = SubcatListSerializer(subcategory, many=True).data
        counts=len(ser)
        expected_data = {
              "count":counts,
              "Subcategores":ser ,}
        json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
        return Response(json_data, status=status.HTTP_200_OK)

class CategoryFromProductApiView(APIView):

  def get(self,request):
    sql="select * from backend_products GROUP BY category_id;"
    category=Products.objects.raw(sql)
    serializer=CategorySerializerProduct(category,many=True).data
    counts=len(serializer)
    expected_data = {
          "count":counts,
          "category":serializer ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

class SubcategoryApiView(APIView):
  def get(self, request, *args, **kwargs):
    category_id = self.kwargs['id']
    state=Products.objects.raw("select * from backend_products where category_id=%s GROUP BY subcategory_id;",[category_id])
    ser = SubcategorySerializerProduct(state, many=True).data
    counts=len(ser)
    expected_data = {
            "count":counts,
              "subcategory":ser ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)

class CountryApiView(APIView):
  def get(self,request):
    sql="select * from backend_products GROUP BY country_id;"
    country=Products.objects.raw(sql)
    serializer=CountrySerializerProduct(country,many=True).data
    counts=len(serializer)
    expected_data = {
          "count":counts,
          "Country":serializer ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

class StateApiView(APIView):
  def get(self, request, *args, **kwargs):
    country_id = self.kwargs['id']
    state=Products.objects.raw("select * from backend_products where country_id=%s GROUP BY state_id;",[country_id])
    ser = StateSerializerProduct(state, many=True).data
    counts=len(ser)
    expected_data = {
            "count":counts,
              "States":ser ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)

class CityApiView(APIView):
  def get(self, request, *args, **kwargs):
    country_id = self.kwargs['id']
    state_id = self.kwargs['id2']
    sql="select * from backend_products where country_id=%(country)s and state_id=%(city)s GROUP BY city_id;"
    params={"country":country_id,"city":state_id}
    city=Products.objects.raw(sql,params)
    serializer=CitySerializerProduct(city,many=True).data
    counts=len(serializer)
    expected_data = {
            "count":counts,
              "city":serializer ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)

class BrandfromProductApiView(APIView):
  def get(self, request, *args, **kwargs):
    sql="select * from backend_products  GROUP BY brand_id;"
    brand=Products.objects.raw(sql)
    serializer=BrandSerializer(brand,many=True).data
    counts=len(serializer)
    expected_data = {
            "count":counts,
              "city":serializer ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)

class ModelApiView(APIView):
  def get(self, request, *args, **kwargs):
    sql="select * from backend_products  GROUP BY model;"
    model=Products.objects.raw(sql)
    serializer=modelSerializer(model,many=True).data
    counts=len(serializer)
    expected_data = {
            "count":counts,
              "model":serializer ,}
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
    return Response(json_data, status=status.HTTP_200_OK)

class priceApiView(APIView):
  def get(self, request, *args, **kwargs):
    obj=Products.objects.annotate(price_int=Cast('price', output_field=FloatField())).aggregate(Max("price_int"),Min('price_int'))
    json_data = {
        "code" : 200,
        "message" : "success",
        "data" :obj
        }
    return Response(json_data , status=status.HTTP_200_OK)


class ExploreAPIView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self, request, format=None,):
    #sql='Select j.* from backend_products j left JOIN  backend_favorite f on j.id = f.pid_id AND f.uid_id=%s  ORDER BY j.id desc limit 10'
    ''''
      page_query_param = 'page'
      page_size = 10
      paginator = PageNumberPagination()
      paginator.page_size = page_size
      paginator.page_query_param = page_query_param
      '''
    uid=request.user.id
    code=request.user.code
    code= code[1:]
    country=Country.objects.filter(code=code)
    serializer=CountrySerializer(country,many=True).data
    country_id=country[0].id
    sql=' SELECT f.is_fav, j.* from backend_products j left JOIN  backend_favorite f  on j.id = f.pid_id '
    sql=sql+' And f.uid_id=%(uid)s WHERE ( j.is_active=1 And j.is_publishing=1 ) and'
    sql=sql+'( j.country_id =%(country_id)s ) ORDER BY j.id desc '
    params={"uid":uid,"country_id":country_id}
        
    queryset = Products.objects.raw(sql,params)
    serializer = ProductFavsSerializer(queryset, many=True)  
    counts=len(serializer.data)
    expected_data = {
          "count":counts,
          "country_id":country_id,
          "Products":serializer.data }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)
class MyproductAPIView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self, request, format=None):
  
    uid=request.user.id
    sql='Select f.is_fav,j.* from backend_products j left JOIN  backend_favorite f on j.id = f.pid_id  AND f.uid_id=%s '
    sql=sql+'  WHERE ( j.is_active=1 And j.is_publishing=1 )  ORDER BY j.id desc limit 10 '
   
    
    queryset = Products.objects.raw(sql,[uid])
    serializer=ProductFavsSerializer(queryset,many=True).data
    counts=len(serializer)
    expected_data = {
           "count":counts,
          "Products":serializer }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

# added ranim
class HistoryApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self,request,format=None):
    uid=request.user
    history_product=History.objects.filter(uid=uid)
    list=[]
    for i in range(len(history_product)):
      list.append(history_product[i].pid.id)
    product= Products.objects.filter(id__in=list)
    serializer=ProductsSerializer(product,many=True).data
    counts=len(serializer)
    expected_data = {
          "count":counts,
          "result":serializer ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

# added ranim
class MyproductsApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self,request,format=None):
    uid=request.user
    product= Products.objects.filter(uid=uid.id).order_by('-id')
    Countrpending= Products.objects.filter(uid=uid.id,is_publishing=0,is_reject=0).count()
    Countreject= Products.objects.filter(uid=uid.id,is_reject=1).count()
    Countactive= Products.objects.filter(uid=uid.id,is_active=1,is_publishing=1,is_reject=0).count()
    Countdisactive= Products.objects.filter(uid=uid.id,is_active=0,is_publishing=1,is_reject=0).count()
    serializer = ProductsSerializer(product, many=True)
    counts=len(serializer.data)
    expected_data = {
          "count":counts,
          "active" : Countactive,
          "dis active":Countdisactive,
          "bending":Countrpending,
          "reject":Countreject,
          "My products":serializer.data ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)
class MyproductsActiveApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self,request,format=None):
    uid=request.user
    product= Products.objects.filter(uid=uid.id,is_active=1,is_publishing=1).order_by('-id')
    serializer = ProductsSerializer(product, many=True)
    counts=len(serializer.data)
    expected_data = {
           "count":counts,
            "My products Active":serializer.data ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)
class MyproductsDisActiveApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self,request,format=None):
    uid=request.user
    product= Products.objects.filter(uid=uid.id,is_active=0,is_publishing=1).order_by('-id')
    serializer = ProductsSerializer(product, many=True)
    counts=len(serializer.data)
    expected_data = {
           "count":counts,
            "My products Active":serializer.data ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)


class MyproductsPendingApiView(APIView):
   permission_classes = [IsAuthenticated]
   def get(self,request,format=None):
    uid=request.user
    product= Products.objects.filter(uid=uid.id,is_publishing=0,is_active=1).order_by('-id')
    serializer = ProductsSerializer(product, many=True)
    counts=len(serializer.data)
    expected_data = {
           "count":counts,
            "My products Active":serializer.data ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

class MyproductsRejectApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self,request,format=None):
    uid=request.user
    product= Products.objects.filter(uid=uid.id,is_reject=1).order_by('-id')
    serializer = ProductsSerializer(product, many=True)
    counts=len(serializer.data)
    expected_data = {
           "count":counts,
            "My products Active":serializer.data ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)
class MyproductsTypeForApiView(APIView):
  permission_classes = [IsAuthenticated]


  def get(self, request, type_for, *args, **kwargs):
    uid=request.user
    ##type_for=0 request buy
    ##type_for=1 request rent
    product= Products.objects.filter(uid=uid.id,is_reject=0,is_publishing=1,is_active=1,type_for=type_for).order_by('-id')
    serializer = ProductsSerializer(product, many=True)
    counts=len(serializer.data)
    expected_data = {
           "count":counts,
            "My products":serializer.data ,}
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

class followApiView(APIView):
  permission_classes = [IsAuthenticated]
  def post(self, request, format=None):

        uid=request.user.id
       # print(uid)
        request.data._mutable = True
        request.data['uid'] = uid
        fuid=request.data['fuid']
       # print( request.data['uid'])
        request.data._mutable = False
        folow= Follow.objects.filter(fuid_id=fuid,uid_id=uid)
        count=len(folow)
        if count!=0:
          folow.delete()
          follow_ser="Deleted"
        else:  
          serializer=FollowSerializer(data=request.data)
          serializer.is_valid(raise_exception=True)
          serializer.save()
          follow_ser=serializer.data
          receiver=fuid
          sender=request.user
          fullname=sender.fullname
          MDevic=FCMDevice.objects.filter(user=receiver,active=1)
          token=MDevic[0].registration_id
          notification = messaging.Notification(title=fullname,body=" Following",)
          message = messaging.Message(notification=notification,token=token,)
          messaging.send(message)
          Notif = Notification.objects.create(uid_id=receiver, is_seen=0,message="From "+ fullname)


        json_data = {
          "code" : 200,
          "message" : "success",
          "follow_ser":follow_ser
          }
        return Response(json_data, status=status.HTTP_200_OK)

  def get(self,request,format=None):

    uid=request.user.id
    count_follow_to=Follow.objects.filter(uid_id=uid).count()
    count_follow_me=Follow.objects.filter(fuid_id=uid).count()
   
    expected_data = {
           "count_follow_me":count_follow_me,
           "count_follow_to":count_follow_to,
         
            }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)


 
class IFUserFollowAPIView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self, request, format=None):
  
    uid=request.user.id
   # users=User.objects.all()
    users=User.objects.filter(id=uid)

    '''
    #sql='SELECT u.id,u.email, w.fuid_id,w.uid_id from backend_user u left JOIN  backend_follow w ON u.id = w.fuid_id WHERE  w.uid_id=%s  AND u.id !=%s ORDER BY u.id asc '
    sql='SELECT u.* from backend_user u left JOIN  backend_follow w ON u.id = w.uid_id And  u.id=%s'
    sql='SELECT f.fuid_id,f.is_follow,u.id from backend_user u LEFT JOIN  backend_follow f on u.id = f.uid_id  AND u.id=%s'
    queryset = User.objects.raw(sql,[uid])

'''

  #  serializer=ProductFavsSerializer(queryset,many=True)
    serializer=UserFolowProfileSerializer(users,many=True).data
    counts=len(serializer)
    follow=Follow.objects.filter(uid=uid)
    expected_data = {
            "uid":uid,
            "count":counts,
            "data": serializer,
        }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

    '''
    isfollow=Follow.objects.filter(uid=uid)

    thisuserfollow=[]
    users.append('is_folow')

    for i in range(len(users)):
       thisuserfollow.append(False)
       thisuserfollow[i]=0
       for j in range(len(isfollow)):
         if users[i].id == isfollow[j].fuid_id : 
            thisuserfollow.append(True)
            thisuserfollow[i]=1
      # users["is_folow"] = thisuserfollow[i]
       #users.update({"is_folow": thisuserfollow[i]})
       users['is_folow'] = thisuserfollow[i]
    print(users)
      # users[i].append(thisuserfollow[i])
    counts=len(isfollow)
   # for i in range(len(users)):
    #  print(users[i].id)
     # print( thisuserfollow[i])
  ''' 




class MyUserFollowAPIView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self, request, format=None):
  
    uid=request.user.id
    sql='SELECT * FROM backend_user WHERE id NOT IN (SELECT backend_follow.fuid_id FROM backend_follow where backend_follow.uid_id=%s) ORDER BY id DESC '
    
    queryset = User.objects.raw(sql,[uid])
    serializer=UserProfileSerializer(queryset,many=True).data
    counts=len(serializer)
    expected_data = {
           "count":counts,
          "Users":serializer }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)



class followtoUserProdApiView(APIView):
  def get(self, request, puid, *args, **kwargs):
    uid=request.user.id
    follow=Follow.objects.filter(uid=uid,fuid=puid)
    serializer = FollowSerializer(follow, many=True)
    counts=len(serializer.data)
    expected_data = {
            "uid":uid,
           "count":counts,
           "My user Follow":serializer.data,
            }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }

    return Response(json_data, status=status.HTTP_200_OK)


class followtousersApiView(APIView):
  permission_classes = [IsAuthenticated]

  def get(self,request,format=None):

    uid=request.user.id
    follow=Follow.objects.filter(uid=uid)
    serializer = FollowToUserSerializer(follow, many=True)
    counts=len(serializer.data)
    expected_data = {
            "uid":uid,
           "count":counts,
           "user":serializer.data,
            }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

  #SELECT u.id, l.uid_id ,l.fuid_id  FROM backend_user u
#left join backend_follow l ON u.id=l.uid_id 
#AND u.id=1
 


   
 
class followfromusersApiView(APIView):
  permission_classes = [IsAuthenticated]

  def get(self,request,format=None):

    uid=request.user.id
    follow=Follow.objects.filter(fuid=uid)
    serializer = FollowFromUserSerializer(follow, many=True)
    counts=len(serializer.data)
    expected_data = {
            "uid":uid,
           "count":counts,
           "user":serializer.data,
            }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

 


class favoritApiView(APIView):
  permission_classes = [IsAuthenticated]
  def post(self, request, format=None):

        uid=request.user.id
        request.data._mutable = True
        request.data['uid'] = uid
        pid=request.data['pid']
        is_fav=request.data['is_fav']
        if is_fav=="1": is_fav=False
        else: is_fav=True
        request.data['is_fav']=is_fav
        request.data._mutable = False
        fav=Favorite.objects.filter(uid_id=uid,pid_id=pid)
        count=len(fav)
        if count==1:
          fav.delete()
          fav_ser="Delete"
          #serializer = FavoritSerializer(instance=fav[0], data = {'is_fav':is_fav}, partial = True)///Edit dis fav
        else :
          serializer=FavoritSerializer(data=request.data)
          serializer.is_valid(raise_exception=True)
          serializer.save()
          fav_ser=serializer.data

        json_data = {
          "code" : 200,
          "count Product":count,
          "message" : "success",
          "fav":fav_ser
          }
        return Response(json_data, status=status.HTTP_200_OK)

  def get(self,request,format=None):

    uid=request.user.id
    sql='SELECT * FROM backend_products WHERE id IN( SELECT pid_id FROM backend_favorite where uid_id=%s)'
    queryset = Products.objects.raw(sql,[uid])
    serializer = ProductFavSerializer(queryset, many=True)
    counts=len(serializer.data)
    expected_data = {
            "uid":uid,
           "count":counts,
           "My products Favorite":serializer.data ,
            }
    json_data = {
      "code" : 200,
      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)

class ApplicationViewApi(APIView):
  def post(self, request, format=None):
    serializer=ApplicationSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    serializer.save()
    json_data = {
      "code" : 200,
      "message" : "success",
       "data":serializer.data
      }
    return Response(json_data, status=status.HTTP_200_OK)

  def get(self,request,format=None):
    app=Application.objects.all().last().id
    version=Application.objects.filter(id=app)
    json_data={
      "code" : 200,
      "version":version[0].version
       }
    return Response(json_data, status=status.HTTP_200_OK)


class NotificationApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get_object(self, msg_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Notification.objects.get(id=msg_id )
        except Notification.DoesNotExist:
            return None

  def get(self, request, msg_id, *args, **kwargs):
        queryset = Notification.objects.filter(id=msg_id)
        serializer = UserNotificationSerializer(queryset, many=True)
        counts=len(serializer.data)

        expected_data = {
      "Mesages":serializer.data

       }
        json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }


        return Response(json_data, status=status.HTTP_200_OK)



import datetime,math
from django.utils import timezone
 
class MynotifsApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get(self,request,format=None):
    uid=request.user
    notifs= Notification.objects.filter(uid=uid.id).order_by('-id')
    i=0
    for notif in notifs:
          
             notif.is_seen = True
             notif.duration= whenpublished(notifs[i].pub_date)
             notif.save()    
             i=i+1
    serializer =UserNotificationSerializer(notifs, many=True)
    counts=len(serializer.data)
    expected_data = {
          "count":counts,
          "My Notifs":serializer.data ,
         }
    json_data = {
      "code" : 200,

      "message" : "success",
      "data" :expected_data
      }
    return Response(json_data, status=status.HTTP_200_OK)


class AsktoorderReplyApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get_object(self, msg_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Askorder.objects.get(id=msg_id )
        except Askorder.DoesNotExist:
            return None

  def post(self, request, msg_id, *args, **kwargs):

        parent = Askorder.objects.filter(id=msg_id)
        receiver=parent[0].sender_id
        print(receiver)
        sender=request.user
        fullname=sender.fullname
   

        ###############
        
        uid=request.user.id
        request.data._mutable = True
        request.data['receiver'] = receiver
        request.data['sender'] = uid
        request.data['parent'] = parent[0].id

        request.data._mutable = False
        serializer = AskorderSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        order = serializer.save()
        '''
          ###############
        reply = Askorder.objects.create(message=request.POST['message'],product=request.POST['product'],
                                        subject=request.POST['subject'],count=request.POST['count'],
                                         from_date=request.POST['from_date'],to_date=request.POST['to_date'],
                                         receiver=receiver, sender=sender, parent=parent)
    
        serializer = UserAskorderSerializer(reply, many=True)
        '''
        
        
        MDevic=FCMDevice.objects.filter(user=receiver,active=1)
        token=MDevic[0].registration_id
        notification = messaging.Notification(title=fullname,body=" You have order from Maxtruck user",)
        message = messaging.Message(notification=notification,token=token,)
        messaging.send(message)
        Notif = Notification.objects.create(uid_id=receiver, is_seen=0,message="MaxTruck User "+ fullname)


        expected_data = {
      "Mesages":serializer.data
       }
        json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }


        return Response(json_data, status=status.HTTP_200_OK)




class AsktoorderApiView(APIView):
  permission_classes = [IsAuthenticated]
  def get_object(self, msg_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Askorder.objects.get(id=msg_id )
        except Askorder.DoesNotExist:
            return None

  def get(self, request, msg_id, *args, **kwargs):
        queryset = Askorder.objects.filter(id=msg_id)
        serializer = UserAskorderSerializer(queryset, many=True)
        counts=len(serializer.data)

        expected_data = {
      "Mesages":serializer.data

       }
        json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }


        return Response(json_data, status=status.HTTP_200_OK)

  def post(self, request, format=None):
      sender=request.user
      fullname=sender.fullname
      uid=request.user.id
      request.data._mutable = True
      request.data['sender'] = uid
      request.data._mutable = False
      serializer = AskorderSerializer(data=request.data)
      serializer.is_valid(raise_exception=True)
      order = serializer.save()
      receiver = serializer.data.get('receiver')
      sender = serializer.data.get('sender')
      product = serializer.data.get('product')
     # initialize_firebase_admin_sdk()
      MDevic=FCMDevice.objects.filter(user=receiver,active=1)
      token=MDevic[0].registration_id
      notification = messaging.Notification(title=fullname,body=" You have order",)
      message = messaging.Message(notification=notification,token=token,)
      messaging.send(message)
      Notif = Notification.objects.create(uid_id=receiver, is_seen=0,message="From "+ fullname)


      expected_data = {
      "sender" : fullname,
      "receiver" :receiver,
      "token":token,
      "order":serializer.data

       }
      json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }
      return Response(json_data, status=status.HTTP_200_OK)


class AskorderApiView(APIView):
    permission_classes = [IsAuthenticated]
    def get_object(self, msg_id):
        '''
        Helper method to get the object with given pro_id
        '''
        try:
            return Askorder.objects.get(id=msg_id )
        except Askorder.DoesNotExist:
            return None
    def get(self, request, *args, **kwargs):
        '''
        '''
        sender=request.user
        messages_sent = Askorder.objects.filter(sender_id=sender,is_read=False).order_by('id')[::-1]
        serializersent = UserAskorderSerializer(messages_sent, many=True, context={'request': request})
        messages_inbox = Askorder.objects.filter(receiver_id=sender,is_read=False).order_by('id')[::-1]
        serializerinbox = UserAskorderSerializer(messages_inbox, many=True, context={'request': request})


        expected_data = {

      "Count Sent Messages":len(serializersent.data),
      "Sent Messages":serializersent.data,
      "Count Inbox Messages":len(serializerinbox.data),
      "Inbox Messages":serializerinbox.data,
       }
        json_data = {
        "code" : 200,
        "message" : "success",
        "data" :expected_data
        }


        return Response(json_data, status=status.HTTP_200_OK)
    def delete(self, request, msg_id, *args, **kwargs):
        '''
        Deletes the  item with given id if exists
        '''
        prod_instance = self.get_object(msg_id)
        if not prod_instance:
            return Response(
                {"res": "Object with Contactus id does not exists"},
                status=status.HTTP_400_BAD_REQUEST
            )
        prod_instance.delete()

        return Response(
            {"res": "Object deleted!"},
            status=status.HTTP_200_OK
        )
from channels.layers import get_channel_layer

class MessageSendAPIView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "general", {"type": "send_info_to_user_group",
                        "text": {"status": "done"}}
        )

        return Response({"status": True}, status=status.HTTP_200_OK)

    def post(self, request):
        msg = Message.objects.create(user=request.user, message={
                                     "message": request.data["message"]})
        socket_message = f"Message with id {msg.id} was created!"
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f"{request.user.id}-message", {"type": "send_last_message",
                                           "text": socket_message}
        )

        return Response({"status": True}, status=status.HTTP_201_CREATED)

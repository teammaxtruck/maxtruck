from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser
from .handle_images import compress_image
from asgiref.sync import async_to_sync


 # Create your models here.
def upload_to(instance, filename):
    
    return 'images/products/{filename}'.format(filename=filename)

def upload_to_u(instance, filename):
    
    return 'images/users/{filename}'.format(filename=filename)    

#------------------------------------
 
 
# Create your models here.
class Country(models.Model):
    country = models.CharField(max_length=50,blank=False,default=1)
    code = models.CharField(max_length=5,blank=False,default=1)
    currency = models.CharField(max_length=5,blank=False,default=1)
    currency_name = models.CharField(max_length=50,blank=False,default=1)
    currency_symbol=models.CharField(max_length=5,blank=False,default=1)

    def __str__(self):
        return self.country


class State(models.Model):
    country = models.ForeignKey(Country, blank=False, related_name='country_state',on_delete=models.CASCADE,default=1)
    state = models.CharField(max_length=50,default="state")

    def __str__(self):
        return self.state


class City(models.Model):
    country = models.ForeignKey(Country, blank=False,related_name='country_city', on_delete=models.CASCADE,default=1)
    state = models.ForeignKey(State, blank=False, on_delete=models.CASCADE,default=1)
    city = models.CharField(max_length=50,default="city")

    def __str__(self):
        return self.city

#   ---------------------------------
class UserManager(BaseUserManager):
    

    def create_user(self, email,fullname,phone,code,type_user, password=None,password2=None):
        """
        Creates and saves a User with the given email, name,tc and password.
        """
        if not email:
            raise ValueError('User must have an email address')

        user = self.model(
            email=self.normalize_email(email),
            fullname=fullname,
            phone=phone,
            code=code,
            type_user=type_user,
           
        )
        
        user.set_password(password)
        user.save(using=self._db)
       
        return user
    

    def create_superuser(self, email,fullname,phone,code,type_user, password=None):
        """
        Creates and saves a superuser with the given email, name,tc, and password.
        """
        user = self.create_user(
            email,
            password=password,
            fullname=fullname,
             phone=phone,
             code=code,
             type_user=type_user,
             
        )
        user.is_admin = True
        user.save(using=self._db)
        return user


#Custom User Model
class User(AbstractBaseUser):
    email = models.EmailField(
        verbose_name='Email',
        max_length=255,
        unique=True,
    )
    fullname=models.CharField(max_length=200)
    identity=models.CharField(max_length=200,null=True)
    document_image=models.ImageField(upload_to=upload_to_u, blank=True, null=True,default='images/users/company1.png')
    profile_image= models.ImageField(upload_to=upload_to_u, blank=True, null=True,default='images/users/person.png')
    type_user=models.IntegerField(blank=True, null=True,default=1) # 1 company 2 person
    phone=models.CharField(max_length=200)
    code=models.CharField(max_length=5,blank=True, null=True)
    country= models.ForeignKey(Country,on_delete=models.CASCADE,related_name='country_user',default=1 )
    is_active = models.BooleanField(default=True)
    is_publish = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    user_token=models.CharField(max_length=250)
    
     # if size greater than 300kb then it will send to compress image function
    def save(
        self,
        force_insert=False,
        force_update=False,
        using=None,
        update_fields=None,
        *args,
        **kwargs,
     ):
        # if size greater than 300kb then it will send to compress image function
        profile_image = self.profile_image
        if profile_image and profile_image.size > (0.3 * 1024 * 1024):
            self.profile_image = compress_image(profile_image)
        document_image = self.document_image
        if document_image and document_image.size > (0.3 * 1024 * 1024):
            self.document_image = compress_image(document_image)    
        super(User, self).save(*args, **kwargs)
    
        

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['fullname','phone']

    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return self.is_admin

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin
   
class Contactus(models.Model):
    uid= models.ForeignKey(User,on_delete=models.CASCADE,default=1 )
    fullname=models.CharField(max_length=200)
    email = models.EmailField(
        verbose_name='Email',
        max_length=255,
        unique=False,
    )
    title=models.CharField(max_length=200)
    message=models.CharField(max_length=200)

class Workers(models.Model):
    name = models.CharField(max_length=50,default=False)
    def get_all_workers():
        return workers.objects.all()


class Services(models.Model):
    name = models.CharField(max_length=50,default=False)
    image = models.ImageField(upload_to=upload_to, blank=True, null=True)
    def get_all_services():
        return Services.objects.all()

 

class Userservices(models.Model):
    uid= models.ForeignKey(User,on_delete=models.CASCADE,default=1 )
    services=models.ForeignKey(Services,on_delete=models.CASCADE,default=1 )
    workers=models.ForeignKey(Workers,on_delete=models.CASCADE,default=1)
    type_user=models.IntegerField(blank=True, null=True,default=1) # 1 company 2 person    
    bio=models.CharField(max_length=150,null=True,blank=True,default="")  # d
    def get_all_Userservices():
        return Userservices.objects.all()


class Currency(models.Model):
    code = models.CharField(max_length=3, default='$')  # works
    name = models.CharField(max_length=50,default=False),  # d
    def get_all_currencies():
        return Currency.objects.all()
    def __str__(self):
        return  (self.code, self.name)


#Custom cats_products Model



class Brands(models.Model):
    name = models.CharField(max_length=100,unique=True)
    image = models.ImageField(upload_to=upload_to, blank=True, null=True)

    is_home = models.BooleanField(default=True)
    def get_all_brands():
        return Brands.objects.all()
   # def __str__(self):
    #    return  (self.name, self.image,self.is_home)
class Categories(models.Model):
    name = models.CharField(max_length=100,unique=True)
    image = models.ImageField(upload_to=upload_to, blank=True, null=True)
    is_home = models.BooleanField(default=True)
   #staticmethod
    #def get_all_categories():
       # return Categories.objects.all()
   # #def __str__(self):
    #    return  (self.name, self.image,self.is_home)

class Subcatgoriess(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to=upload_to, blank=True, null=True)
    cats = models.ForeignKey(Categories, on_delete=models.CASCADE,default=1)


    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']



class Products(models.Model):
    N = "New"
    U = "Used"
    CONDITION_TYPES = (
        (N, 'New'),
        (U, 'Used'),
    )
  
    uid= models.ForeignKey(User,on_delete=models.CASCADE,default=1 ,related_name='user')
    name=models.CharField(max_length=200)
    condition=models.CharField(choices=CONDITION_TYPES, max_length=20,default="N")
    model=models.CharField(max_length=50, null=True, blank=True)
    manufacturedate=models.CharField(max_length=50, null=True, blank=True)
    manufacturcountry=models.ForeignKey(Country,on_delete=models.CASCADE,related_name='manufacture',default=1)
    price = models.DecimalField(decimal_places=2, max_digits=10, null=True, blank=True,default=0)
    currency = models.ForeignKey(Country ,on_delete=models.CASCADE,related_name='currencycode',default=1 )
    type_for=models.CharField(max_length=200)
    category= models.ForeignKey(Categories,on_delete=models.CASCADE,related_name='cat_prod',default=1 )
    brand= models.ForeignKey(Brands,on_delete=models.CASCADE,related_name='brand_prod',default=1 )
    country= models.ForeignKey(Country,on_delete=models.CASCADE,related_name='country_prod',default=1 )
    state= models.ForeignKey(State,on_delete=models.CASCADE,default=1 )
    city= models.ForeignKey(City,on_delete=models.CASCADE,default=1 )
    description= models.TextField(max_length=2500, default='', blank=True, null= True)
    image1=models.CharField(max_length=50, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_publishing = models.BooleanField(default=False)
    is_reject = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    '''
         def save(
        self,
        force_insert=False,
        force_update=False,
        using=None,
        update_fields=None,
        *args,
        **kwargs,
     ):
        # if size greater than 300kb then it will send to compress image function
        image = self.image
        if image and image.size > (0.3 * 1024 * 1024):
            self.image = compress_image(image)
        super(Products, self).save(*args, **kwargs)

    '''    
        
   
    @staticmethod
    def get_products_by_id(ids):
        return Products.objects.filter (id__in=ids)
    @staticmethod
    def get_all_products():
        return Products.objects.all()

    @staticmethod
    def get_all_products_by_categoryid(category_id):
        if category_id:
            return Products.objects.filter (category=category_id)
        else:
            return Products.get_all_products();
    

from django.utils.html import mark_safe

class Images(models.Model):
    product=models.ForeignKey(Products,on_delete=models.CASCADE,default=1,related_name='images' )
    image = models.ImageField(upload_to=upload_to, blank=True, null=True)
    is_main = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    def save(
            self,
            force_insert=False,
            force_update=False,
            using=None,
            update_fields=None,
            *args,
            **kwargs,
        ):
            # if size greater than 300kb then it will send to compress image function
            image = self.image
            if image and image.size > (0.3 * 1024 * 1024):
                self.image = compress_image(image)
            super(Images, self).save(*args, **kwargs)
                    
    def image_tag(self):
            return mark_safe('<img src="/directory/%s" width="150" height="150" />' % (self.image))

    image_tag.short_description = 'image'
class History(models.Model):
    pid=models.ForeignKey(Products,on_delete=models.CASCADE)
    uid=models.ForeignKey(User,on_delete=models.CASCADE)
    ctaid=models.ForeignKey(Categories,on_delete=models.CASCADE,null=True)
    subcat=models.ForeignKey(Subcatgoriess,on_delete=models.CASCADE,null=True)
    date=models.DateTimeField(auto_now=True,null=True)


    
class HistorySearch(models.Model):
    uid=models.ForeignKey(User,on_delete=models.CASCADE)
    keywords=models.CharField(max_length=50,null=True,blank=True)
    date=models.DateTimeField(auto_now=True,null=True)


class Favorite(models.Model):
    pid=models.ForeignKey(Products,on_delete=models.CASCADE,related_name='favs')
    uid=models.ForeignKey(User,on_delete=models.CASCADE)
    is_fav=models.BooleanField(default=True)
    created_at=models.DateTimeField(auto_now_add=True,null=True,blank=True)
    def current_Fav():
        return Favorite.objects.filter(is_fav=True)
        
class Follow(models.Model):
    uid=models.ForeignKey(User,on_delete=models.CASCADE,related_name='follow_from')
    fuid=models.ForeignKey(User,on_delete=models.CASCADE,related_name='follow_to')
    is_follow=models.BooleanField(default=True)
    is_deleted=models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True,null=True,blank=True)
    def current_Foloww():
        return Follow.objects.all()

class Application(models.Model):
    version=models.CharField(max_length=40)
    updated_at=models.DateTimeField(auto_now=True)  


class Messages(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sender_m')
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='receiver_m')
    message = models.CharField(max_length=1200)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    
    #objects = models.Manager()
    def __str__(self):
        return self.messages

    class Meta:
        ordering = ('timestamp',)
class Askorder(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sender')
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='receiver')
    product = models.ForeignKey(Products, on_delete=models.CASCADE, related_name='orderproducts')
    is_rent=models.BooleanField(default=True)
    subject= models.CharField(max_length=50)
    count= models.IntegerField()
    from_date = models.DateTimeField(auto_now=True,null=True)
    to_date = models.DateTimeField(auto_now=True,null=True)
    message = models.CharField(max_length=1200,null=True,blank=True,default="MaxTrucks")
    is_read = models.BooleanField(default=False)
    parent = models.ForeignKey('self', on_delete=models.CASCADE,
                            null=True, blank=True, related_name='reply_parent')
    timestamp = models.DateTimeField(auto_now_add=True)

    
    def get_children(self):
        return Askorder.objects.filter(parent=self)

    def __str__(self):
        return '{} to {} :{}'.format(self.sender,self.receiver,self.message)
    class Meta:
        ordering = ('timestamp',)

from datetime import timedelta
from django.utils import timezone
import math
class Notification(models.Model):
    uid = models.ForeignKey(User, on_delete=models.CASCADE, related_name='usernot')
    is_seen=models.BooleanField(default=False)
    message = models.CharField(max_length=1200)
    pub_date = models.DateTimeField(auto_now_add=True)
    duration =models.CharField(max_length=50)
    
    '''
    def whenpublished(self):
        now = timezone.now()
        
        diff= now - self.pub_date

        if diff.days == 0 and diff.seconds >= 0 and diff.seconds < 60:
            seconds= diff.seconds
            
            if seconds == 1:
                return str(seconds) +  "second ago"
            
            else:
                return str(seconds) + " seconds ago"

            

        if diff.days == 0 and diff.seconds >= 60 and diff.seconds < 3600:
            minutes= math.floor(diff.seconds/60)

            if minutes == 1:
                return str(minutes) + " minute ago"
            
            else:
                return str(minutes) + " minutes ago"



        if diff.days == 0 and diff.seconds >= 3600 and diff.seconds < 86400:
            hours= math.floor(diff.seconds/3600)

            if hours == 1:
                return str(hours) + " hour ago"

            else:
                return str(hours) + " hours ago"

        # 1 day to 30 days
        if diff.days >= 1 and diff.days < 30:
            days= diff.days
        
            if days == 1:
                return str(days) + " day ago"

            else:
                return str(days) + " days ago"

        if diff.days >= 30 and diff.days < 365:
            months= math.floor(diff.days/30)
            

            if months == 1:
                return str(months) + " month ago"

            else:
                return str(months) + " months ago"


        if diff.days >= 365:
            years= math.floor(diff.days/365)

            if years == 1:
                return str(years) + " year ago"

            else:
                return str(years) + " years ago"

   ''' #################
   
    def __str__(self):
        return self.message

    class Meta:
        ordering = ('pub_date',)


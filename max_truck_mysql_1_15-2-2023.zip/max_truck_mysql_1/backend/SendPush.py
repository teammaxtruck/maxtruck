import FCMManager as fcm

tokens = ["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjczNjQxODUzLCJp"
        "YXQiOjE2NzE5MTM4NTMsImp0aSI6IjI2OTEyNWM4NGM3MTQxMWNhYzkxNWZhNjBmN2RmOTA5IiwidXNlcl9pZCI6MX0.JRYDm4zeL29sJm6ucnJ8Jjm0ciBpkkns0e79IQY4oKc"]
fcm.sendPush("Hi", "This is my next msg", tokens)
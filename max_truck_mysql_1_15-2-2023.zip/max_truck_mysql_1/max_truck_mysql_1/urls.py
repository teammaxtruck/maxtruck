from django.contrib import admin
from django.urls import path  , include
from django.conf.urls.static import static
from rest_framework_simplejwt.views import (TokenObtainPairView,
                                            TokenRefreshView)
from . import settings
from backend.views import MessageSendAPIView
urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/' , include('backend.urls')),
    path('api/user/', include('backend.urls')),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('message/', MessageSendAPIView.as_view()),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
